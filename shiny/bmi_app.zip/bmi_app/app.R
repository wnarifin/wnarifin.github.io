library(shiny)

# Define UI ----
ui <- fluidPage(
  titlePanel("My BMI"),
  
  sidebarLayout(
    sidebarPanel(
      textInput("weight", h3("Weight (in kg)")),
      textInput("height", h3("Height (in cm)"))
    ),
    mainPanel(
      h3("Your BMI:"),
      h3(textOutput("bmi"))
  )
  )
)

# Define server logic ----
server <- function(input, output) {
  output$bmi = renderText({
    weight_ = as.numeric(input$weight)
    height_ = as.numeric(input$height)
    bmi_ = weight_/(height_*.01)^2
    round(bmi_, digits = 1 )
    })
}

# Run the app ----
shinyApp(ui = ui, server = server)